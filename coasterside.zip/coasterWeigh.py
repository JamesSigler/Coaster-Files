#! /usr/bin/python2

import schedule
import time
import sys
import requests as r
import json
import subprocess
import os



EMULATE_HX711=False

referenceUnit = 1

 
def main():
    
    coasterID = 5
    
    
    if not EMULATE_HX711:
        import RPi.GPIO as GPIO
        from hx711 import HX711
    else:
        from emulated_hx711 import HX711


    hx = HX711(5, 6)


    hx.set_reading_format("MSB", "MSB")


    hx.set_reference_unit(419)
    hx.set_reference_unit(referenceUnit)

    hx.reset()

    hx.tare()

    

    
    getCoasterInfoUrl = 'http://192.168.0.32/ws/custom/fullCoaster.php?coasterId=' + str(coasterID)
    
    postNewDrinkLevelUrl = 'http://192.168.0.32/ws/coaster/update/updateAll.php?coasterId=' + str(coasterID) + '&drinkLevel='
    
    while True:
        #get drink info from the server
        '''
        this is how the program would normally call the webservice and get the data, 
        however since we cannot be in the same spot, we are just going to use mock data
        for the coaster demo
        
        response = r.get(getCoasterInfoUrl)
        jsnDict = eval(response.text)
        drinkId = jsonDict['drinkId']
        drinkTop = jsonDict['drinkWeightTop']
        drinkMid = jsonDict['drinkWeightMiddle']
        drinkTop = jsonDict['drinkWeightBottom']
        
        example json return 
        {"coasterId":"5","tableNumber":"29","drinkId":"2","drinkLevel":"0.18","drinkWeightTop":"9.0185","drinkWeightMiddle":"6.4073","drinkWeightBottom":"3.9682","drinkDescription":"Dr. Pepper"}
        
        '''

        print("Fake Webservice call")
        #set paroty values 
        drinkTop = 9.0185
        drinkMid = 6.4073
        drinkBot = 3.9682
        
        #get the weight 
        weight = max( 1, int(hx.get_weight(5)))/28.3
        print(weight)
        print("Updating server")
        time.sleep(5) 
        hx.power_down()
        hx.power_up()
        
        #conditions in order to assign the proper level to the coaster 
        
        if weight > drinkTop:
            #printing because in person test of webservice was impossible due to
            #corona
            print('Drink Full')
            
            '''
            req = requests.post(postNewDrinkLevelUrl + str(1))
            
            #only call it 5 times if it doesnt work 
            maxIts = 5
            i = 0
            while i < maxIts and req.text != 'true':
                req = requests.post(postNewDrinkLevelUrl + str(1))
                i += 1

            '''
            
        elif weight > drinkMid:
            #calculate level
            """
            To be more accurate we came up with this algorithim in order to
            get the percentage of this range that it is full, then if it is lower
            it will get the percentage of that range, in case the distance between
            the mid and top and bottom are very different
            """
            rng = drinkTop - drinkMid
            dif = weight - drinkMid
            
            percent = ((dif/rng) / 2) + 0.5
            
            #printing because in person test of webservice was impossible due to
            #corona
            print(percent)
            
            '''
            
            #updating webserver with new level
            req = requests.post(postNewDrinkLevelUrl + str(percent))
            
            #only call it 5 times if it doesnt work 
            maxIts = 5
            i = 0
            while i < maxIts and req.text != 'true':
                req = requests.post(postNewDrinkLevelUrl + str(percent))
                i += 1
            
            
            
            '''
            
            
        elif weight < drinkBot:
            rng = drinkMid - drinkBot
            dif = weight - drinkBot
            
            percent = ((dif/rng) / 2)
            #printing because in person test of webservice was impossible due to
            #corona
            print('near empty')
            
            '''
            
            #updating webserver with new level
            req = requests.post(postNewDrinkLevelUrl + str(percent))
            
            #only call it 5 times if it doesnt work 
            maxIts = 5
            i = 0
            while i < maxIts and req.text != 'true':
                req = requests.post(postNewDrinkLevelUrl + str(percent))
                i += 1
                
            '''
        #else:
            #if the weight is out of range, then do not call webserver because 
            #there is probably some error, wait for next pass to diagnose 
            #this accounts for drinks not being on the coaster 
            

            
            
        
main()  
    #schedule.every(1).minutes.do(main,'/ws/custom/fullCoaster.php?coasterid=10')